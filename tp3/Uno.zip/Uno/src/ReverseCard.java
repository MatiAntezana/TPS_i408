public class ReverseCard extends NonWildCard{
    public ReverseCard(String ColorCard) {
        super(ColorCard);
    }
}
