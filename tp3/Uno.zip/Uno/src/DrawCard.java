public class DrawCard extends NonWildCard{
    public DrawCard(String ColorCard){
        super(ColorCard);
    }
}
