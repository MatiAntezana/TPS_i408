abstract class NonWildCard extends Card {
    protected String color;

    public NonWildCard(String color) { this.color = color; }
    public String getColor() { return this.color; }
}