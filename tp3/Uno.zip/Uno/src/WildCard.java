class WildCard extends Card {
    public WildCard() {}
}
