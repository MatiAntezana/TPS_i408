public class SkipCard extends NonWildCard{
    public SkipCard(String ColorCard) {
        super(ColorCard);
    }
}
