public abstract class Card {
}