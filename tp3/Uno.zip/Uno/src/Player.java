public class Player {
    public String name;
    public Integer CantCardsPlayer;
    public Player(String PlayerName, Integer CantCards) {
        name = PlayerName;
        CantCardsPlayer = CantCards;

    }
}
